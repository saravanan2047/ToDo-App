package com.example.myroomapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myroomapp.database.Item
import com.example.myroomapp.itemList.ItemAdapter
import com.example.myroomapp.itemList.ItemViewModel
import com.example.myroomapp.itemList.ItemViewModelFactory


class MainActivity : AppCompatActivity() {

    private val itemViewModel: ItemViewModel by viewModels {
        ItemViewModelFactory(application)
    }
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextItem = findViewById<EditText>(R.id.editTextItem)
        val buttonAdd = findViewById<Button>(R.id.buttonAdd)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        adapter = ItemAdapter { item ->
            itemViewModel.delete(item)
            Toast.makeText(this, "${item.name} deleted", Toast.LENGTH_SHORT).show()
        }

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        itemViewModel.allItems.observe(this, Observer { items ->
            items?.let { adapter.setItems(it) }
        })

        buttonAdd.setOnClickListener {
            val itemName = editTextItem.text.toString()
            if (itemName.isNotBlank()) {
                itemViewModel.insert(Item(name = itemName))
                editTextItem.text.clear()
            } else {
                Toast.makeText(this, "Item name cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
